package at.htl.leonding.androidrestapi.model

data class Rendered(val rendered: String) {
}